"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { AlertCircle, Copy, Check } from "lucide-react"

export default function Base64Converter() {
  const [input, setInput] = useState("")
  const [output, setOutput] = useState("")
  const [error, setError] = useState("")
  const [copied, setCopied] = useState(false)

  const encodeToBase64 = () => {
    try {
      setError("")
      const encoded = btoa(input)
      setOutput(encoded)
    } catch (err) {
      setError("Failed to encode: Input contains characters outside of the Latin1 range")
    }
  }

  const decodeFromBase64 = () => {
    try {
      setError("")
      const decoded = atob(input)
      setOutput(decoded)
    } catch (err) {
      setError("Failed to decode: Input is not valid base64")
    }
  }

  const copyToClipboard = () => {
    navigator.clipboard.writeText(output)
    setCopied(true)
    setTimeout(() => setCopied(false), 2000)
  }

  const handleTabChange = (value: string) => {
    setInput("")
    setOutput("")
    setError("")
  }

  return (
    <div className="container max-w-3xl py-10">
      <h1 className="text-3xl font-bold text-center mb-8">Base64 Encoder/Decoder</h1>

      <Tabs defaultValue="encode" onValueChange={handleTabChange}>
        <TabsList className="grid w-full grid-cols-2 mb-6">
          <TabsTrigger value="encode">Encode</TabsTrigger>
          <TabsTrigger value="decode">Decode</TabsTrigger>
        </TabsList>

        <TabsContent value="encode">
          <Card>
            <CardHeader>
              <CardTitle>Encode to Base64</CardTitle>
              <CardDescription>Convert plain text to base64 encoded string</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Textarea
                  placeholder="Enter text to encode"
                  className="min-h-[120px]"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                />
              </div>

              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div>
                <Textarea
                  placeholder="Base64 output will appear here"
                  className="min-h-[120px]"
                  value={output}
                  readOnly
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button onClick={encodeToBase64} disabled={!input}>
                Encode
              </Button>
              <Button variant="outline" onClick={copyToClipboard} disabled={!output} className="flex gap-2">
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                {copied ? "Copied!" : "Copy"}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>

        <TabsContent value="decode">
          <Card>
            <CardHeader>
              <CardTitle>Decode from Base64</CardTitle>
              <CardDescription>Convert base64 encoded string back to plain text</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Textarea
                  placeholder="Enter base64 to decode"
                  className="min-h-[120px]"
                  value={input}
                  onChange={(e) => setInput(e.target.value)}
                />
              </div>

              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div>
                <Textarea
                  placeholder="Decoded output will appear here"
                  className="min-h-[120px]"
                  value={output}
                  readOnly
                />
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button onClick={decodeFromBase64} disabled={!input}>
                Decode
              </Button>
              <Button variant="outline" onClick={copyToClipboard} disabled={!output} className="flex gap-2">
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                {copied ? "Copied!" : "Copy"}
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

